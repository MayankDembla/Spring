package com.dembla.pizzashop.builder;

import com.dembla.pizzashop.domain.Order;
import com.dembla.pizzashop.domain.Pizza;

abstract class OrderBuilder {
	
	protected Order order ;
	
	public Order getPizza() {
		return order;
	}

	public void setPizza(Order order) {
		this.order = order;
	} 
	
    public abstract void add(Pizza pizza) ; 	
    
}
