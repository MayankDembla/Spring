package com.dembla.pizzashop.builder;

import com.dembla.pizzashop.domain.BaseTopping;
import com.dembla.pizzashop.domain.Pizza;

abstract class PizzaBuilder {
	
	protected Pizza pizza ;
	
	public Pizza getPizza() {
		return pizza;
	}

	public void setPizza(Pizza pizza) {
		this.pizza = pizza;
	} 
	
    public abstract void addTopping(BaseTopping topping) ; 	
    
}
