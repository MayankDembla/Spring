package com.dembla.pizzashop.builder;

import com.dembla.pizzashop.domain.BaseTopping;

public class PizzaBuilderImpl extends PizzaBuilder {

	PizzaBuilderImpl(String name , String type ) { 
		
		// Set Name and Type
		pizza.getBase().setPizzaName(name);
        pizza.setType(type);
        
        // Add Base Cost to Pizza
        pizza.setCost(pizza.getBase().getCost(type));
	}
	
	@Override
	public void addTopping(BaseTopping topping) {

		// Add the Topping on Pizza
		pizza.getTopping().add(topping) ; 
 		
		// Update its Cost 
		pizza.setCost(pizza.getCost() + topping.getCost());
		
	}

}
