package com.dembla.pizzashop.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PizzaController {

	@GetMapping("/orderPizza")
	public String orderPizza(Model model) { 
	  
		return "showmenu" ; 
	}
	
	@GetMapping("/showmenu")
	public String showMenu(Model model) { 
		return "showMenu";
	}
	
}
