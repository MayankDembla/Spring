package com.dembla.pizzashop.domain;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class BasePizza {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long baseid;

	private String pizzaName;

	private int small;

	private int medium;

	private int large;

	@OneToMany(mappedBy = "base")
	private List<Pizza> pizza;

	public Long getId() {
		return baseid;
	}

	public void setId(Long baseid) {
		this.baseid = baseid;
	}

	public String getPizzaName() {
		return pizzaName;
	}

	public void setPizzaName(String pizzaName) {
		this.pizzaName = pizzaName;
	}

	public int getSmall() {
		return small;
	}

	public void setSmall(int small) {
		this.small = small;
	}

	public int getMedium() {
		return medium;
	}

	public void setMedium(int medium) {
		this.medium = medium;
	}

	public int getLarge() {
		return large;
	}

	public void setLarge(int large) {
		this.large = large;
	}

	public int getCost(String name) {

		switch (name) {
		case "small":
			return this.small;
		case "medium":
			return this.medium;
		case "large":
			return this.large;
		}

		return 0;
	}

}
