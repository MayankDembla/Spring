package com.dembla.pizzashop.repository;

import com.dembla.pizzashop.domain.BasePizza;
import com.dembla.pizzashop.domain.BaseTopping;

public interface PizzaRepository extends GenericDao<BasePizza, Long> {
	
	BasePizza getPizza(String pizzaName , String size) ; 
	
	BaseTopping getTopping(String toppingName ) ; 

}
