package com.dembla.pizzashop.repository;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.dembla.pizzashop.domain.BasePizza;
import com.dembla.pizzashop.domain.BaseTopping;

@Repository
public class PizzaRepositoryImpl extends HibernateDao<BasePizza, Long> implements PizzaRepository {

	@Override
	public BasePizza getPizza(String pizzaName, String size) {

		Criteria criteria = currentSession().createCriteria(BasePizza.class);
		criteria.add(Restrictions.eq("pizzaName", pizzaName));
		criteria.add(Restrictions.eq("size", size));

		return (BasePizza) criteria.list().get(0);
	}

	@Override
	public BaseTopping getTopping(String toppingName) {

		Criteria criteria = currentSession().createCriteria(BaseTopping.class);
		criteria.add(Restrictions.eq("topping", toppingName));
		return (BaseTopping) criteria.list().get(0);
	}

}
