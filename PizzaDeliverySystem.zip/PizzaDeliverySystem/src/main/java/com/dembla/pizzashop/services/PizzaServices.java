package com.dembla.pizzashop.services;

public interface PizzaServices {
	
	/**
	 * this is to commit order for a particular customer  
	 */
	void orderPizza(String pizzaName , String type) ;
	
	

}
